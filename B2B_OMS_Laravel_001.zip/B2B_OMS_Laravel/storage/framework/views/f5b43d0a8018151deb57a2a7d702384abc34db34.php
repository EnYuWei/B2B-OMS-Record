<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B2B OMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('build/asset/app.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>

<body>

    <nav class="navbar">
        <img src="img/ChinChun2002_Logo.jpg" alt="Logo" class="navbar-logo">
        <a href="#"><i class="fa fa-home"></i>Home</a>
        <a href="#"><i class="fa fa-file"></i> Sales Order</a>
        <a href="#"><i class="fa fa-file"></i> Purchase Order</a>
        <a href="#"><i class="fa fa-cubes"></i> Stock</a>
        <a href="#"><i class="fa fa-clone"></i> Sample</a>
        <a href="#"><i class="fa fa-industry"></i> Supplier</a>
        <a href="#"><i class="fa fa-window-maximize"></i> Product</a>
        <a href="#"><i class="fa fa-ship"></i>Shipment</a>
        <a href="#"><i class="fa fa-cog"></i> Settings</a>
    </nav>

    <header>
        <span id="title">Dashboard</span>
        <div class="user">
            <img src="img/user.png"  alt="User" id='account-img' onclick="toggleMenu()">            
            <span class="account-name"><?php echo e(Session::get('user_account')); ?></span>             
        </div>

        <div class="user-menu">
            <a href="/" >Sign out</a>
            <a href="#">
                <select id="language" name="language">
                    <option value="" style="display: none;">Language</option>
                    <option value="English">English</option>
                    <option value="Chinese">แบบไทย</option>
                    <option value="Thai">中文</option>
                </select>
            </a>
        </div>
    </header>

    <section>
        <!-- 其他主要内容 -->
        <?php echo e($slot); ?>

    </section>
            
        
    </div>

<script>
// 點擊頭像顯示或隱藏使用者功能列
function toggleMenu() 
{
    var menu = document.querySelector(".user-menu");
    if (menu) 
    {
        menu.style.display = (menu.style.display === "block") ? "none" : "block";
    }
}

// 點擊其他地方時關閉菜單
document.addEventListener('click', function (event) 
{
    var menu = document.querySelector(".user-menu");
    var userIcon = document.getElementById('account-img');
    if (menu && userIcon && !userIcon.contains(event.target) && !menu.contains(event.target))
    {
        menu.style.display = 'none';
    }
});

</script>

</body>
</html>

<?php /**PATH C:\Users\asus\B2B_OMS_Laravel\resources\views/components/layout.blade.php ENDPATH**/ ?>