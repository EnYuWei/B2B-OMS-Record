<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f2f5;
        }
        .container {
            text-align: center;
        }
        .login-form {
            background: #fff;
            padding: 35px;
            border-radius: 8px;        
            box-shadow: 0px 3px 15px 0 rgba(0,0,0,.15);
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 90%;
            padding: 10px;
            font-size: large;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-form button {
            margin-top: 25px;
            width: 90%;
            padding: 10px;
            border: none;
            background-color: #04AA6D;
            color: #fff;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-form button:hover {
            background-color: #166666;
        }
        .error-message {
            display: none;
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chin Chun Enterprise 2002</h1>
        <p>Welcome</p>
        <form class="login-form" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="account" placeholder="帳號" required>
            <input type="password" id="passwordInput" name="password" placeholder="密碼" required><br>
            <input type="checkbox" onclick="displayPassword()">顯示密碼
            <button type="submit"><b>登入</b></button>
        </form>
        <?php if($errors->any()): ?>
            <script>
                // 在 DOM 加載後顯示錯誤訊息
                document.addEventListener('DOMContentLoaded', function() {
                    alert('<?php echo e(implode("\n", $errors->all())); ?>');
                });
            </script>
         <?php endif; ?>
    </div>

    
<script>
    // 顯示密碼
    function displayPassword() 
    {
        var x = document.getElementById("passwordInput");
        if (x.type === "password") 
        {
            x.type = "text";
        } 
        else 
        {
            x.type = "password";
        }
    }
</script>
    
</body>
</html><?php /**PATH C:\Users\asus\B2B_OMS_Laravel\resources\views/login.blade.php ENDPATH**/ ?>