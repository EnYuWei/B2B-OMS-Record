<x-layout>
    <h1>Home</h1>
</x-layout>