<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('login'); // 返回登入頁面視圖
    }

    public function login(Request $request)
    {
        $request->validate([
            'account' => 'required|string',
            'password' => 'required|string',
        ]);

        $account = $request->input('account');
        $password = $request->input('password');

        // 查詢資料庫
        $user = DB::table('使用者帳號對應表')->where('帳號', $account)->first();

        // 直接比較密碼
        if ($user && $password === $user->密碼) 
        {
            // 設置 session
            Session::put('user_account', $user->帳號);
            Session::put('user_role', $user->角色);

            // 驗證成功，重定向到主頁面
            return redirect()->route('home') . $account; // 使用路由名稱進行重定向
        } 
        else 
        {
            // 驗證失敗，返回登入頁面並顯示錯誤信息
            return redirect()->back()->withErrors(['帳號或密碼輸入有誤!']);
        }
    }
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/')->with('message', 'Successfully logged out!');
    }
}